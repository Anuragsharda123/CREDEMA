$(document).ready(function() {
    $(".mul-select").select2({
        placeholder: "Select Skills",
        tags: true,
    });
})